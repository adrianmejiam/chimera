# Deezer
# -------
# Tracks    : 720599342, 717409502, 456184882 (E), 15392959 (360 audio)
# Albums    : 7463461, 93205012, 7090505
# Playlists : 5761818702 (53 Tracks), 4365127622 (11 Tracks), 6323608564 (10 Tracks)
# Artists   :

# Tidal
# -------
# Tracks    : 113297575, 112722095, 79683151, 98869489
# Albums    : 26531974, 22964847
# Playlists : e0a2a508-eeb0-4939-b933-e00a06d83687, ee210a7d-ffba-4fdf-a0b1-31c763b2c6d1, af6a2ed2-e61a-455e-aed7-1549abc4622e
# Artists   :

# Qobuz
# -------
# Tracks    : 64366361, 53668164, 10446095 (96kHz), 14876249 (48kHz), 5382709 (88.2kHz), 63417045 (E)
# Albums    : wu7uac4147csc, 0886444469319, 0744861111375
# Playlists : 1595257 (100 Tracks), 1784198 (17 Tracks), 1423255 (11 Tracks)
# Artists   :

# Spotify
# -------
# Tracks    :
# Albums    :
# Playlists :
# Artists   : 7dGJo4pcD2V6oG8kP0tJRR, 6DPYiyq5kWVQS4RGwxzPC7, 6wWVKhxIU2cEi0K81v7HvP

# Napster
# -------
# Tracks    : 365693021
# Albums    : alb.365693020
# Playlists :
# Artists   :

# GPM
# -------
# Tracks    : Tswhyxgv4dkxo5ikcwrz7qrtmiy, Tezaec4c3uevgt2dofwuyvvk2ku, Tq6qa72uzg2d2ok2ou4nkrpqtwu
# Albums    : alb.365693020
# Playlists :
# Artists   :
